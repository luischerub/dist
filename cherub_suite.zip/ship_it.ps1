# --- CONFIGURATION ---
$DevDir     = "C:\Users\Luis Cherubini\Dropbox\Softwares\Github\cherub-suite"
$DistDir    = "C:\Users\Luis Cherubini\Dropbox\Softwares\Github\dist"
$BlenderExe = "C:\Users\Luis Cherubini\Dropbox\Softwares\Blender\Blender_versions\blender_dev\blender-5.1.0-windows-x64\blender.exe"
$AddonName  = "cherub_suite"

# --- 1. CLEANUP ---
Write-Host "Cleaning up previous distribution files..." -ForegroundColor Cyan
if (Test-Path "$DistDir\$AddonName.zip") { Remove-Item "$DistDir\$AddonName.zip" }

# --- 2. PACKAGING ---
Write-Host "Zipping extension from Dev folder..." -ForegroundColor Green
# Using -Exclude is tricky in Compress-Archive, so we filter the files first
$Files = Get-ChildItem -Path "$DevDir\*" -Exclude ".git*", "*.zip", "__pycache__", ".vscode", ".gitignore", "tests"
Compress-Archive -Path $Files -DestinationPath "$DistDir\$AddonName.zip" -Force

# --- 3. BLENDER REPOSITORY INDEX ---
Write-Host "Updating local repository index..." -ForegroundColor Yellow
Set-Location $DistDir

# Using the & operator to execute the specific portable blender.exe
& $BlenderExe --command extension build-repository --output index.json

# --- 4. DEPLOYMENT (GIT PUSH) ---
Write-Host "Pushing to GitHub distribution repo..." -ForegroundColor Magenta
git add .
$Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm"
git commit -m "Deployment: $Timestamp"
git push origin main

Write-Host "Deployment successful! Extension is live at your dist repo." -ForegroundColor Green
Set-Location $DevDir